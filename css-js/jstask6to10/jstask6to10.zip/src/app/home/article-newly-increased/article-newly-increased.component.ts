import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-article-newly-increased',
  templateUrl: './article-newly-increased.component.html',
  styleUrls: ['./article-newly-increased.component.scss'],
})
export class ArticleNewlyIncreasedComponent implements OnInit {
  date: any = {};
  value = '';
  constructor() {}

  ngOnInit(): void {}
}
