import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './wellcome.component.html',
  styleUrls: ['./wellcome.component.scss']
})
export class WellcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
