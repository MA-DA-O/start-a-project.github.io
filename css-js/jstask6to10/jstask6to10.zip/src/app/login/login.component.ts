import { Component, OnInit } from '@angular/core';
import { RouterLink, Router } from '@angular/router'; // 导入router服务
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
} from '@angular/forms';
import { NzFormModule } from 'ng-zorro-antd/form';
import { from } from 'rxjs';
import { style } from '@angular/animations';
import {
  HttpClient,
  HttpClientModule,
  HttpHeaders,
} from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
  }),
};

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  isVisible = false;
  public user = '';
  public password = '';
  validateForm!: FormGroup;
  submitForm(): void {
    // tslint:disable-next-line: forin
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
  }

  constructor(
    private fb: FormBuilder,
    private router: Router,
    public http: HttpClient
  ) {} // 在构造函数声明router,声明各个实例articleList

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      userName: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true],
    });
  }
  showModal(): void {
    // const httpHeaders = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/x-www-form-urlencoded',
    //   }),
    // };
    console.log(this);
    console.log(this.user, this.password);
    let api = '/ajax/';
    this.http
      .post(
        `${api}a/login`,
        this.paramFormat({ name: this.user, pwd: this.password }),
        httpOptions  // 请求头
      )
      .subscribe((response) => {
        console.log(response);
        if (response === 0) {
        }
      });

    // if (this.user == 'user' && this.password == 'password') {
    //   this.router.navigateByUrl('home/wellcome');
    // } else {
    //   this.isVisible = true;
    // }
  }

  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  handleCancel(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  // 序列化参数
  paramFormat(data: any) {
    let paramStr = '',
      name,
      value,
      subName,
      innerObj;
    let that = this;
    for (name in data) {
      value = data[name];
      if (value instanceof Array) {
        for (let i of value) {
          subName = name;
          innerObj = {};
          innerObj[subName] = i;
          paramStr += this.paramFormat(innerObj) + '&';
        }
      } else if (value instanceof Object) {
        Object.keys(value).forEach(function (key) {
          subName = name + '[' + key + ']';
          innerObj = {};
          innerObj[subName] = value[key];
          paramStr += that.paramFormat(innerObj) + '&';
        });
      } else if (value !== undefined && value !== null) {
        paramStr +=
          encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
      }
    }
    return paramStr.length ? paramStr.substr(0, paramStr.length - 1) : paramStr;
  }
}
